suspects = {
	"suspect1": {
		"name": "sarah",
		"facial hair": "yes",
		"scarf": "no",
		"hat": "yes",
		"old": "No",
		"pet": "yes",
		"glasses": "yes"
	},
	"suspect2": {
		"name": "nina",
		"facial hair": "no",
		"scarf": "yes",
		"hat": "no",
		"old": "yes",
		"pet": "yes",
		"glasses": "no"
	},
	"suspect3": {
		"name": "dee",
		"facial hair": "yes",
		"scarf": "no",
		"hat": "yes",
		"old": "yes",
		"pet": "yes",
		"glasses": "no"
	},
	"suspect4": {
		"name": "alison",
		"facial hair": "yes",
		"scarf": "no",
		"hat": "no",
		"old": "yes",
		"pet": "no",
		"glasses": "yes"
	},
	"suspect5": {
		"name": "anthony",
		"facial hair": "no",
		"scarf": "no",
		"hat": "yes",
		"old": "no",
		"pet": "no",
		"glasses": "no"
	},
	"suspect6": {
		"name": "christy",
		"facial hair": "no",
		"scarf": "yes",
		"hat": "yes",
		"old": "no",
		"pet": "no",
		"glasses": "yes"
	}
}
