suspects = {
	"suspect1": {
		"name": "anthony",
		"facial hair": "yes",
		"scarf": "no",
		"hat": "yes",
		"freckles": "No",
		"pet": "yes",
		"glasses": "yes"
	},
	"suspect2": {
		"name": "nina",
		"facial hair": "no",
		"scarf": "yes",
		"hat": "no",
		"freckles": "yes",
		"pet": "yes",
		"glasses": "no"
	},
	"suspect3": {
		"name": "dee",
		"facial hair": "yes",
		"scarf": "no",
		"hat": "yes",
		"freckles": "yes",
		"pet": "yes",
		"glasses": "no"
	},
	"suspect4": {
		"name": "alison",
		"facial hair": "yes",
		"scarf": "no",
		"hat": "no",
		"freckles": "yes",
		"pet": "no",
		"glasses": "yes"
	},
	"suspect5": {
		"name": "sarah",
		"facial hair": "no",
		"scarf": "no",
		"hat": "yes",
		"freckles": "no",
		"pet": "no",
		"glasses": "no"
	},
	"suspect6": {
		"name": "christy",
		"facial hair": "no",
		"scarf": "yes",
		"hat": "yes",
		"freckles": "no",
		"pet": "no",
		"glasses": "yes"
	}
}
