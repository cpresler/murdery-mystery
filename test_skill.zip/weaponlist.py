
weapon_list = ["sharp stiletto",
"zombie kitten",
"saber tooth rubber ducky",
"half eaten Oreo",
"wet sock",
"rainbow titanium butterfly knife", 
"Nickelback album", 
"state of the art Midi Fighter Spectra",
"Playstation 4",
"$25 Amazon gift card", 
]

