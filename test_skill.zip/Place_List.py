
place_of_murdery = ["Teracai room",
"Fiber Tech Theater",
"bathroom",
"hall",
"kitchen",
"sandbox",
"Axa Tower",
"parking garage",
"bus terminal",
]
